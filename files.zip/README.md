# Trimurti Travels Website — Setup Guide

## Files Included
| File | Description |
|---|---|
| `style.css` | Shared white & blue theme stylesheet |
| `components.php` | Shared header, nav, WhatsApp float button, booking popup |
| `footer.php` | Shared footer + all JavaScript |
| `index.php` | Home page |
| `about.php` | About Us |
| `services.php` | Our Services |
| `packages.php` | All Tour Packages |
| `transport.php` | Bus, Car Rental & Airport Transfer |
| `banaras.php` | Haridwar–Varanasi Bus Service |
| `gallery.php` | Photo Gallery |
| `testimonials.php` | Client Testimonials |
| `contact.php` | Contact Us (WhatsApp form) |

## WhatsApp Integration
- Floating WhatsApp button: **+91-9888991549** (on every page)
- Booking popup → sends formatted booking message to **+91-9888991549**
- Contact form → sends enquiry to **+91-9888991549**
- Quick enquiry buttons on contact page for specific tour types

## Server Requirements
- **PHP 7.4+** (for `date()` and `require` statements)
- Any standard web host (cPanel, VPS, shared hosting)
- Upload all files to your `public_html` folder

## How to Deploy
1. Upload all files to your hosting `public_html/` (or a subfolder like `public_html/trimurti/`)
2. Visit `https://yourdomain.com/index.php` in a browser
3. All pages will work immediately — no database or PHP configuration needed

## To Change WhatsApp Number
Open `components.php`, find this line near the top:
```php
$wa_number = "919888991549";
```
Replace with the new number in international format (no + sign).

## Adding Real Images
Replace the emoji icons in `packages.php` and `gallery.php` with real `<img>` tags:
```html
<img src="images/chardham.jpg" alt="Chardham Yatra" style="width:100%;height:100%;object-fit:cover">
```
Place your images in an `images/` folder alongside the PHP files.

## Design Theme
- **Primary Blue:** `#1e4db7`
- **Dark Blue:** `#0a2463`  
- **Accent Gold:** `#f59e0b`
- **Fonts:** Playfair Display (headings) + Poppins (body)
