<?php
$page_title = "Best Travel Agent in Haridwar | Chardham Yatra & Bus Services";
$page = "home";
require 'components.php';
?>

<!-- ═══ HERO ═══ -->
<section class="hero">
  <div class="hero-mountains"></div>
  <div class="container">
    <div class="hero-content">
      <div class="hero-badge">🕉️ Chardham Yatra 2025 Open</div>
      <h2>Your Sacred Journey<br>Begins in <span>Haridwar</span></h2>
      <p>Trusted travel companion for pilgrims &amp; explorers since 1997. Chardham tours, luxury buses, temple circuits &amp; adventure packages across North India.</p>
      <div class="hero-ctas">
        <button class="btn-primary" onclick="openBooking()">📋 Book Now — Free Enquiry</button>
        <a href="packages.php" class="btn-outline">🗺️ View All Packages</a>
      </div>
      <div class="hero-stats">
        <div class="stat"><div class="stat-num">26+</div><div class="stat-label">Years Experience</div></div>
        <div class="stat"><div class="stat-num">500+</div><div class="stat-label">Happy Pilgrims</div></div>
        <div class="stat"><div class="stat-num">50+</div><div class="stat-label">Destinations</div></div>
        <div class="stat"><div class="stat-num">24/7</div><div class="stat-label">Support</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ SERVICES ═══ -->
<section>
  <div class="container">
    <div class="section-header">
      <div class="section-tag">What We Offer</div>
      <h2>Our Core Services</h2>
      <p>From luxury coaches to helicopter yatras, we cover every aspect of your sacred and leisure travel</p>
      <div class="divider"></div>
    </div>
    <div class="services-grid">
      <div class="service-card">
        <div class="service-icon">🚌</div>
        <h3>Luxury Coach Services</h3>
        <p>Volvo, Deluxe, Mini Coaches &amp; Tempo Travellers — well-maintained with professional drivers for Chardham &amp; North India tours.</p>
      </div>
      <div class="service-card">
        <div class="service-icon">🕉️</div>
        <h3>Chardham Yatra</h3>
        <p>Complete Chardham packages with hotel, prasad darshan, puja arrangements at Badrinath, Kedarnath, Gangotri &amp; Yamunotri.</p>
      </div>
      <div class="service-card">
        <div class="service-icon">🚁</div>
        <h3>Helicopter Yatra</h3>
        <p>Exclusive Chardham by helicopter packages for a swift and comfortable pilgrimage. Pre-booking available for 2025 season.</p>
      </div>
      <div class="service-card">
        <div class="service-icon">✈️</div>
        <h3>Airport Transfer</h3>
        <p>Reliable transfers to/from Jolly Grant Airport Dehradun &amp; Indira Gandhi International Airport Delhi.</p>
      </div>
      <div class="service-card">
        <div class="service-icon">🎒</div>
        <h3>Adventure Tours</h3>
        <p>Rafting in Rishikesh, trekking, camping, wildlife safaris at Jim Corbett — curated adventure packages for all ages.</p>
      </div>
      <div class="service-card">
        <div class="service-icon">🚗</div>
        <h3>Car Rental</h3>
        <p>SUVs, sedans &amp; mini cabs available for self-driven or chauffeur-driven tours across Uttarakhand &amp; North India.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══ POPULAR PACKAGES ═══ -->
<section class="packages-bg">
  <div class="container">
    <div class="section-header">
      <div class="section-tag">Top Picks</div>
      <h2>Popular Tour Packages</h2>
      <p>Carefully curated packages for pilgrims, families and adventure seekers</p>
      <div class="divider"></div>
    </div>
    <div class="packages-grid">

      <div class="package-card">
        <div class="package-img" style="background:linear-gradient(135deg,#0a2463,#1e4db7)">
          🏔️
          <span class="package-badge">Best Seller</span>
        </div>
        <div class="package-body">
          <span class="package-tag">Pilgrimage</span>
          <h3>Chardham Yatra</h3>
          <div class="package-meta">
            <span>📅 9 Nights / 10 Days</span>
            <span>🚌 AC Bus</span>
          </div>
          <p>Complete Chardham circuit — Yamunotri, Gangotri, Kedarnath &amp; Badrinath with hotel and meals.</p>
          <a href="packages.php#chardham" class="btn-blue">View Details</a>
        </div>
      </div>

      <div class="package-card">
        <div class="package-img" style="background:linear-gradient(135deg,#064e3b,#065f46)">
          🛕
          <span class="package-badge">Popular</span>
        </div>
        <div class="package-body">
          <span class="package-tag">Pilgrimage</span>
          <h3>Do Dham Tour</h3>
          <div class="package-meta">
            <span>📅 5 Nights / 6 Days</span>
            <span>🚌 AC Coach</span>
          </div>
          <p>Badrinath &amp; Kedarnath — the two most sacred shrines of Lord Vishnu and Shiva in Uttarakhand.</p>
          <a href="packages.php#dodham" class="btn-blue">View Details</a>
        </div>
      </div>

      <div class="package-card">
        <div class="package-img" style="background:linear-gradient(135deg,#1e3a5f,#2d6a9f)">
          🏞️
        </div>
        <div class="package-body">
          <span class="package-tag">Nature</span>
          <h3>Nainital – Corbett</h3>
          <div class="package-meta">
            <span>📅 7 Nights / 8 Days</span>
            <span>🚗 Cab</span>
          </div>
          <p>Lakes, hill stations &amp; jungle safaris — a perfect family holiday in Kumaon Himalaya.</p>
          <a href="packages.php#nainital" class="btn-blue">View Details</a>
        </div>
      </div>

      <div class="package-card">
        <div class="package-img" style="background:linear-gradient(135deg,#7c2d12,#b45309)">
          🌊
        </div>
        <div class="package-body">
          <span class="package-tag">Adventure</span>
          <h3>Rafting Tour Rishikesh</h3>
          <div class="package-meta">
            <span>📅 1 Night / 2 Days</span>
            <span>🚣 River Rafting</span>
          </div>
          <p>White-water rafting on the holy Ganga at Shivpuri with bonfire camping under the stars.</p>
          <a href="packages.php#rafting" class="btn-blue">View Details</a>
        </div>
      </div>

    </div>
    <div class="text-center" style="margin-top:36px">
      <a href="packages.php" class="btn-blue" style="font-size:15px;padding:13px 34px">View All Packages →</a>
    </div>
  </div>
</section>

<!-- ═══ DAILY BUS ROUTES ═══ -->
<section>
  <div class="container">
    <div class="section-header">
      <div class="section-tag">Daily Departures</div>
      <h2>Bus Routes from Haridwar</h2>
      <p>Regular bus services for pilgrimage, leisure &amp; corporate travel across North India</p>
      <div class="divider"></div>
    </div>
    <div class="routes-grid">
      <div class="route-item"><div class="route-icon">🚌</div><div class="route-text"><strong>Haridwar → Chardham</strong><span>9N/10D · AC Deluxe Coach</span></div></div>
      <div class="route-item"><div class="route-icon">🕉️</div><div class="route-text"><strong>Haridwar → Badrinath</strong><span>3N/4D · Daily Departure</span></div></div>
      <div class="route-item"><div class="route-icon">⛰️</div><div class="route-text"><strong>Haridwar → Kedarnath</strong><span>4N/5D · Group Tours</span></div></div>
      <div class="route-item"><div class="route-icon">🌊</div><div class="route-text"><strong>Haridwar → Gangotri</strong><span>2N/3D · Seasonal</span></div></div>
      <div class="route-item"><div class="route-icon">🌸</div><div class="route-text"><strong>Haridwar → Yamunotri</strong><span>2N/3D · Seasonal</span></div></div>
      <div class="route-item"><div class="route-icon">🏙️</div><div class="route-text"><strong>Haridwar → Varanasi</strong><span>Sleeper Coach · Overnight</span></div></div>
      <div class="route-item"><div class="route-icon">🕌</div><div class="route-text"><strong>Haridwar → Ayodhya</strong><span>AC Bus · Pilgrimage</span></div></div>
      <div class="route-item"><div class="route-icon">🇳🇵</div><div class="route-text"><strong>Haridwar → Nepal</strong><span>International Bus Service</span></div></div>
      <div class="route-item"><div class="route-icon">🌄</div><div class="route-text"><strong>Haridwar → Mussoorie</strong><span>Day Trip Available</span></div></div>
      <div class="route-item"><div class="route-icon">🏔️</div><div class="route-text"><strong>Haridwar → Nainital</strong><span>Weekend Packages</span></div></div>
      <div class="route-item"><div class="route-icon">🦁</div><div class="route-text"><strong>Haridwar → Jim Corbett</strong><span>Wildlife Safari Package</span></div></div>
      <div class="route-item"><div class="route-icon">🏛️</div><div class="route-text"><strong>Haridwar → Agra / Delhi</strong><span>AC Coach · Daily</span></div></div>
    </div>
    <div class="text-center" style="margin-top:32px">
      <p style="color:var(--gray-600);margin-bottom:14px">📞 Call for Booking: <strong style="color:var(--blue-dark)">+91-1334-227879 / 226989</strong></p>
      <button class="btn-primary" onclick="openBooking()">Book Your Seat Now</button>
    </div>
  </div>
</section>

<!-- ═══ ABOUT STRIP ═══ -->
<section style="background:var(--blue-sky);padding:60px 0">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:50px;align-items:center">
      <div>
        <div class="section-tag">About Trimurti Travels</div>
        <h2 style="font-family:'Playfair Display',serif;font-size:34px;color:var(--blue-dark);margin:12px 0 16px">
          Haridwar's Most Trusted Travel Company
        </h2>
        <p style="color:var(--gray-600);line-height:1.8;margin-bottom:16px">
          Trimurti Travels has been Haridwar's leading travel agency since 1997. Specialising in Chardham Yatra, adventure tours and North India bus services, we have served over 500+ satisfied clients with an impeccable record of safety and comfort.
        </p>
        <p style="color:var(--gray-600);line-height:1.8;margin-bottom:24px">
          We are registered with the Government of Uttarakhand and are approved sales agents for Railway &amp; Air tickets. Our fleet includes GPS-enabled luxury coaches, Volvo buses and Tempo Travellers driven by experienced professionals.
        </p>
        <a href="about.php" class="btn-blue">Read Our Story →</a>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div style="background:var(--white);border-radius:var(--radius);padding:24px;text-align:center;box-shadow:var(--shadow)">
          <div style="font-size:40px;margin-bottom:8px">🏅</div>
          <strong style="color:var(--blue-dark)">Govt. Registered</strong>
          <p style="font-size:12.5px;color:var(--gray-600);margin-top:4px">Uttarakhand Tourism Approved</p>
        </div>
        <div style="background:var(--white);border-radius:var(--radius);padding:24px;text-align:center;box-shadow:var(--shadow)">
          <div style="font-size:40px;margin-bottom:8px">🚌</div>
          <strong style="color:var(--blue-dark)">Own Fleet</strong>
          <p style="font-size:12.5px;color:var(--gray-600);margin-top:4px">Luxury coaches &amp; cabs</p>
        </div>
        <div style="background:var(--white);border-radius:var(--radius);padding:24px;text-align:center;box-shadow:var(--shadow)">
          <div style="font-size:40px;margin-bottom:8px">🙏</div>
          <strong style="color:var(--blue-dark)">Special Pujas</strong>
          <p style="font-size:12.5px;color:var(--gray-600);margin-top:4px">Abhishek &amp; darshan arrangements</p>
        </div>
        <div style="background:var(--white);border-radius:var(--radius);padding:24px;text-align:center;box-shadow:var(--shadow)">
          <div style="font-size:40px;margin-bottom:8px">✈️</div>
          <strong style="color:var(--blue-dark)">Air &amp; Rail Tickets</strong>
          <p style="font-size:12.5px;color:var(--gray-600);margin-top:4px">Approved IATA &amp; IRCTC agent</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ WHY CHOOSE US ═══ -->
<section>
  <div class="container">
    <div class="section-header">
      <div class="section-tag">Why Choose Us</div>
      <h2>The Trimurti Difference</h2>
      <div class="divider"></div>
    </div>
    <div class="why-grid">
      <div class="why-card">
        <div class="why-icon">🏆</div>
        <h3>26+ Years Experience</h3>
        <p>Decades of expertise in Uttarakhand pilgrimage and North India travel management.</p>
      </div>
      <div class="why-card">
        <div class="why-icon">💰</div>
        <h3>Best Price Guarantee</h3>
        <p>Competitive pricing with no hidden charges. Best value for every budget.</p>
      </div>
      <div class="why-card">
        <div class="why-icon">🛡️</div>
        <h3>Safe &amp; Reliable</h3>
        <p>GPS-tracked fleet, trained drivers, 24/7 support and emergency assistance.</p>
      </div>
      <div class="why-card">
        <div class="why-icon">🙏</div>
        <h3>Puja Arrangements</h3>
        <p>Special pujas, abhisheks and darshan arrangements at all major shrines.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══ TESTIMONIALS ═══ -->
<section class="testimonials-bg">
  <div class="container">
    <div class="section-header">
      <div class="section-tag">Happy Pilgrims</div>
      <h2>What Our Travellers Say</h2>
      <div class="divider"></div>
    </div>
    <div class="testimonials-grid">
      <div class="testimonial-card">
        <div class="stars">★★★★★</div>
        <p>"The Chardham tour was absolutely well organised. Every hotel, transport and puja arrangement was exactly as promised. Trimurti Travels made our yatra divine and stress-free."</p>
        <div class="reviewer">
          <div class="reviewer-avatar">🙏</div>
          <div><div class="reviewer-name">Ramesh Sharma</div><div class="reviewer-loc">Delhi, India</div></div>
        </div>
      </div>
      <div class="testimonial-card">
        <div class="stars">★★★★★</div>
        <p>"We booked a Nainital family trip and the service was outstanding. The cab driver was knowledgeable and the hotels were excellent. Will definitely book again!"</p>
        <div class="reviewer">
          <div class="reviewer-avatar">👨‍👩‍👧</div>
          <div><div class="reviewer-name">Priya Agarwal</div><div class="reviewer-loc">Lucknow, UP</div></div>
        </div>
      </div>
      <div class="testimonial-card">
        <div class="stars">★★★★★</div>
        <p>"Best travel agent in Haridwar without doubt. Their Varanasi sleeper bus service is very comfortable and punctual. I use them for every trip now!"</p>
        <div class="reviewer">
          <div class="reviewer-avatar">🚌</div>
          <div><div class="reviewer-name">Suresh Gupta</div><div class="reviewer-loc">Haridwar, UK</div></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ MAP ═══ -->
<div class="map-section">
  <iframe
    src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13828.459250562775!2d78.156743!3d29.947376!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x9228f88d6457b6c4!2sTrimurti+Travels!5e0!3m2!1sen!2sin!4v1425407665317"
    allowfullscreen loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"
    title="Trimurti Travels Location">
  </iframe>
</div>

<?php require 'footer.php'; ?>
